#pragma strict

var frameDelay : int = 3;
	

/*** �X�N���v�g�R���|�[�l���g ***/
/*private var playerInput : PlayerInput;
private var charaInput : CharaInput;
private var charaStateCtrl : CharaStateCtrl;
private var charaMove : CharaMove;
private var charaStatus : CharaStatus;
*/

/****************************************************************/
/*
function Awake () {
	enabled = false;
	
	playerInput = GameObject.Find("GameController").GetComponent(PlayerInput);
	
	charaStateCtrl = GetComponent(CharaStateCtrl);
	charaInput = GetComponent(CharaInput);
	charaMove = GetComponent(CharaMove);
	charaStatus = GetComponent(CharaStatus);
}

function Start () {
	while (true) {
		// �z�X�g
		if (PhotonNetwork.isMasterClient) {
			yield playerInput.WaitForGuestInput();
			charaStateCtrl.Set();
			charaMove.Set();
			charaInput.Set();
			
		// �Q�X�g
		} else {
			playerInput.Get();
			yield charaMove.Set();
		}
	}
}
*/