#pragma strict

var dashSE : AudioClip;
var fireSE : AudioClip;

/******************************************************************************/

function Start ()
{
}

function Update ()
{
}