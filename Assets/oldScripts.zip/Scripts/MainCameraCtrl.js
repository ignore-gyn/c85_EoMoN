#pragma strict

var maxOffsetZ : float = -35.0;
var maxOffsetY : float;

private var minOffsetZ : float;
private var minOffsetY : float;
private var offsetZ : float;
private var offsetY : float;

var max2r : float = 45.0;
var min2r : float = 20.0;

var tan60 : float;


var initRX : float = 60.0;
var initRY : float = 0;
var initRZ : float = 0;

/*var initPX : float = 0.0;
var initPY : float = 60.0;		// 60.62178
var initPZ : float = -35.0;

var initRX : float = 90.0;
var initRY : float = 0;
var initRZ : float = 0;*/

var initFOV : float = 33.5;	// fieldOfView

var x0 : float;
var x1 : float;
var z0 : float;
var z1 : float;

var midX : float;
var midZ : float;

var rotX : float;
var posZ : float;
var posY : float;
var dist : float;

function Start () {
	tan60 = Mathf.Tan(Mathf.Deg2Rad * initRX);
	maxOffsetY = -maxOffsetZ * tan60;
	offsetY = maxOffsetY / max2r;
	offsetZ = maxOffsetZ / max2r;
	minOffsetY = offsetY * min2r;
	minOffsetZ = offsetZ * min2r;
	
	/*Camera.main.transform.position.x = 0.0;
	Camera.main.transform.position.z = offsetZ;
	Camera.main.transform.position.y = offsetY;*/
}

function Update () {	//LateUpdate?
	
	var tiger : GameObject = GameObject.FindWithTag("Tiger");
	var bunny : GameObject = GameObject.FindWithTag("Bunny");

	if (tiger.transform.position.x >= bunny.transform.position.x) {
		x1 = tiger.transform.position.x;
		x0 = bunny.transform.position.x;
	} else {
		x0 = tiger.transform.position.x;
		x1 = bunny.transform.position.x;
	}
	
	if (tiger.transform.position.z >= bunny.transform.position.z) {
		z1 = tiger.transform.position.z;
		z0 = bunny.transform.position.z;
	} else {
		z0 = tiger.transform.position.z;
		z1 = bunny.transform.position.z;
	}
	
	midX = x0 + (x1 - x0) * 0.5;
	midZ = z0 + (z1 - z0) * 0.5;
	
	/* 2r = sqrt((x*0.75)^2 + z^2)*/
	dist = Mathf.Sqrt((x1 - x0) * (x1 - x0) * 0.5625 + (z1 - z0) * (z1 - z0));
	
	if (dist > max2r) {
		Camera.main.transform.position.x = midX;
		Camera.main.transform.position.z = midZ + maxOffsetZ;
		Camera.main.transform.position.y = maxOffsetY;
	} else if (dist < min2r) {
		Camera.main.transform.position.x = midX;
		Camera.main.transform.position.z = midZ + minOffsetZ;
		Camera.main.transform.position.y = minOffsetY;
	} else {
		Camera.main.transform.position.x = midX;
		Camera.main.transform.position.z = midZ + (offsetZ * dist);
		Camera.main.transform.position.y = offsetY * dist;
		
 	/*} else {*/
		/* メインカメラの回転原点は(0, 60, 35) */
		/*Camera.main.transform.position.x = midX;
		
		rotX = initRX - (100.0 - dist) * 0.6;
		if (rotX < 0) rotX = 0;
		
		Camera.main.transform.rotation.eulerAngles = Vector3(rotX, 0, 0);
		
		posZ = Mathf.Cos(Mathf.Deg2Rad * (initRX - rotX)) * (initPZ + offsetZ);
		posY = Mathf.Sin(Mathf.Deg2Rad * (initRX - rotX)) * (initPZ + offsetZ);
		posY =  offsetY + posY * 2;
		if (posY < 1.0) posY = 1.0;
		
		Camera.main.transform.position.z = posZ + midZ;
		Camera.main.transform.position.y = posY;*/
	}
}

