#pragma strict

var skin : GUISkin;

private var tigerStatus : CharaStateCtrl;
private var bunnyStatus : CharaStateCtrl;

private var labelText : String = "";

function Awake() {
	enabled = false;
}

function Start() {
	tigerStatus = GameObject.FindWithTag("Tiger").GetComponent(CharaStateCtrl);
	bunnyStatus = GameObject.FindWithTag("Bunny").GetComponent(CharaStateCtrl);
}


function OnGUI () {
	if (tigerStatus == null || bunnyStatus == null) return;
	
	var tigerHp : float = tigerStatus.charaHp; 
	var bunnyHp : float = bunnyStatus.charaHp;
	var tigerhpText : String;
	var bunnyhpText : String;

	var uiW : float = Screen.width / 8;
	var uiH : float = Screen.height;
	
	var uiX : float = Screen.width - uiW;
	
	tigerhpText = "HP\n" +  tigerHp.ToString() + "\n/1000";
	bunnyhpText = "HP\n" +  bunnyHp.ToString() + "\n/1000";

	GUI.skin = skin;
	
	// Create two sides boxes and show two characters' HP
	GUI.Box (Rect (0,0,uiW,uiH), tigerhpText);
	GUI.Box (Rect (uiX, 0,uiW,uiH), bunnyhpText);
	
	if (labelText != "") {
		GUI.Box(Rect(0, (Screen.height-100)/2, Screen.width, 100),
		        labelText);
	}
}

function TimeUp () {
    // Back to main menu
    labelText = "Time Up";
	yield WaitForSeconds(3);
	Application.LoadLevel(Application.loadedLevel - 1);
}
