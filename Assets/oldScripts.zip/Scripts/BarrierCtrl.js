#pragma strict

private var charaStateCtrl : CharaStateCtrl;

function Start () {
	charaStateCtrl = transform.parent.GetComponent(CharaStateCtrl);
}

function Update () {
	var state = charaStateCtrl.GetState();
	
	if (state != CharaState.BARR) {
		Destroy(gameObject);
	}
}
