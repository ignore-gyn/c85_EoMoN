#pragma strict

/*** �R���|�[�l���g ***/
var roundStatus : RoundStatus;
var photonView : PhotonView;
private var publicData : PublicData;


private var waitTime : int = 3;
private var sw : int;
private var sh : int;

private var labelText : String = "";

/*****************************************************************/

function Start()
{
	// *** Debug ***
	if (GameObject.Find("DataKeeper") == null) {
		Application.LoadLevel(Application.loadedLevel - 1);
        return;
	}
	// *************
	
	publicData = GameObject.Find("DataKeeper").GetComponent(PublicData);
	
    // PhotonNetwork.logLevel = NetworkLogLevel.Full;
    if (!publicData.isOfflineMode && !PhotonNetwork.connected)
    {
        // We must be connected to a photon server! Back to main menu
        Application.LoadLevel(Application.loadedLevel - 1);
        return;
    }
	
	sw = Screen.width;
	sh = Screen.height;
}

function OnGUI()
{
    if (GUI.Button(Rect(Screen.width/8, 0, 120, 17), "Return to Lobby"))
    {
        PhotonNetwork.LeaveRoom();
    }
    
    if (labelText != "") {
    	GUI.Box(Rect(0, 0, Screen.width, Screen.height), labelText);
    }
}

function OnLeftRoom()
{
    Debug.Log("OnLeftRoom (local)");
    
    // back to main menu
    yield WaitForSeconds(waitTime);
    Application.LoadLevel(Application.loadedLevel - 1);
}

function OnMasterClientSwitched(player : PhotonPlayer)
{
    Debug.Log("OnMasterClientSwitched: " + player);

    if (PhotonNetwork.connected)
    {
        photonView.RPC("SendChatMessage", PhotonNetwork.masterClient,
                       "Hi master! From:" + PhotonNetwork.player);
        photonView.RPC("SendChatMessage", PhotonTargets.All,
                       "WE GOT A NEW MASTER: " + player + "==" + PhotonNetwork.masterClient +
                       " From:" + PhotonNetwork.player);
    }
}

function OnDisconnectedFromPhoton()
{
    Debug.Log("OnDisconnectedFromPhoton");

    // Back to main menu
    labelText = "Disconnected.";
	yield WaitForSeconds(waitTime);
	Application.LoadLevel(Application.loadedLevel - 1);
}



function OnPhotonPlayerDisconnected(player : PhotonPlayer)
{
    Debug.Log("OnPlayerDisconneced: " + player);
    
    labelText = "NetworkPlayer Left the room.";
    yield WaitForSeconds(waitTime);
    Application.LoadLevel(Application.loadedLevel - 1);
}

function OnReceivedRoomList()
{
    Debug.Log("OnReceivedRoomList");
}

function OnReceivedRoomListUpdate()
{
    Debug.Log("OnReceivedRoomListUpdate");
}

function OnConnectedToPhoton()
{
    Debug.Log("OnConnectedToPhoton");
}

function OnFailedToConnectToPhoton()
{
    Debug.Log("OnFailedToConnectToPhoton");
    
    labelText = "Disconnected.";
    yield WaitForSeconds(waitTime);
    Application.LoadLevel(Application.loadedLevel - 1);
}

function OnPhotonInstantiate(info : PhotonMessageInfo)
{
    Debug.Log("OnPhotonInstantiate " + info.sender);
}

