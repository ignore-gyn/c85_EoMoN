﻿#pragma strict

var bulletAPrefab : GameObject;
var bulletBPrefab : GameObject;

var myTransform : Transform;
var enemyTransform  : Transform;

/******************************************************************************/
function Start ()
{
	myTransform = transform;
	enemyTransform = GetComponent(CharaAction).enemyTransform;
	
}


function makeBulletA() {
	var bullet : GameObject = Instantiate(bulletAPrefab,
	                                      Vector3(transform.position.x, 3, transform.position.z),
	                                      transform.rotation);
	
	bullet.GetComponent(BulletACtrl).target = GetComponent(CharaAction).enemy;
}

function makeBulletB() {
	
	var moveDirection : Quaternion = Quaternion.Euler(90, 0, 0);
	moveDirection = Quaternion.LookRotation(Vector3.right,
		                                    enemyTransform.position
	                                        - myTransform.position);
	
	//Quaternion.Euler(90, myTransform.eulerAngles.y, 0)
	
	//Quaternion.LookRotation(GetComponent(CharaAction).enemyTransform.position - transform.position, Vector3.up);
	
	var bullet1 : GameObject = Instantiate(bulletBPrefab,
	                                      Vector3(transform.position.x+0.8,
	                                               3,
	                                               transform.position.z),
	                                       Quaternion.Euler(90, 0, 0));
	
	var bullet2 : GameObject = Instantiate(bulletBPrefab,
	                                       Vector3(transform.position.x-0.8,
	                                               3,
	                                               transform.position.z),
	                                       Quaternion.Euler(90, 0, 0));
	bullet2.transform.parent = bullet1.transform;
	
	bullet1.transform.eulerAngles = Vector3(90, myTransform.eulerAngles.y, 0);
		
	bullet1.GetComponent(BulletBCtrl).target = GetComponent(CharaAction).enemy;
	bullet2.GetComponent(BulletBCtrl).target = GetComponent(CharaAction).enemy;
}

