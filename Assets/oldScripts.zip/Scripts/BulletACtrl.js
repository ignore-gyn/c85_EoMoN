﻿#pragma strict

var target : GameObject;		// この弾が当たるターゲット(弾を作るオブジェクトが登録する)

/*** 弾のパラメータ ***/
var bulletPower : float = 10.0;
var bulletSpeed : float = 20.0;

var bulletVelocity : Vector3;

/******************************************************************************/

function Start () {
	rigidbody.velocity = transform.forward * bulletSpeed;
}

function Update () {
	
}

function OnTriggerEnter (other : Collider) {
	// ぶつかったオブジェクトがターゲットであれば、ダメージを与え消滅する
	if (other.gameObject == target) {
		other.gameObject.SendMessage("ApplyDamage", bulletPower);
		Destroy(gameObject);
	}
}
