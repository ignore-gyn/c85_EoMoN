#pragma strict
var skin : GUISkin;

var updateInterval : float = 1.0;				// �X�V�p�x(s)
private var elapsed : float = 0.0;				// �o�ߎ���
private var nextIntervalTimer : float;			// ���̍X�V�܂ł̎���
private var numFrames : int = 0;
private var prvGameFrame : int;

private var text : String = "";
private var fpsText : String = "";
private var myFrameText : String = "";
private var otherFrameText : String = "";
private var stateFrameText : String = "";
private var gameFrameText : String = "";

private var playerInput : PlayerInput;
private var charaStateSync : CharaStateSync;
private var roundStatus : RoundStatus;

function Start () {
	playerInput = GetComponent(PlayerInput);
	charaStateSync = GetComponent(CharaStateSync);
	roundStatus = GetComponent(RoundStatus);
	
	nextIntervalTimer = updateInterval;
	prvGameFrame = roundStatus.gameFrame;
}

function Update () {
	nextIntervalTimer -= Time.deltaTime;
	elapsed += Time.deltaTime / Time.timeScale;
	numFrames++;
	
	if (nextIntervalTimer <= 0) {
		text = "";
		
		// FPS�v�Z
		var fps : float = numFrames / elapsed;
		var inputFps : float = (roundStatus.gameFrame - prvGameFrame) / elapsed;
		
		fps = Mathf.Round(fps * 100) / 100;
		inputFps = Mathf.Round(inputFps * 100) / 100;
		
		//text += "elapsed: " + elapsed + "\n";
		text += "realFPS: " + inputFps + "\n";
		text += "FPS: " + fps + "\n";
		
		text += "inputTigerF: " + playerInput.inputTigerFrame + "\n";
		text += "inputBunnyF: " + playerInput.inputBunnyFrame + "\n";
		text += "gameF: " + roundStatus.gameFrame + "\n";
		
		// ������
		nextIntervalTimer = updateInterval;
		elapsed = 0;
		numFrames = 0;
		prvGameFrame = roundStatus.gameFrame;
	}
}

function OnGUI () {
	var sw : int = Screen.width;
	var sh : int = Screen.height;
	
	GUI.skin = skin;
	GUI.Label(Rect(sw-120, sh-100, sw, sh), text);
}