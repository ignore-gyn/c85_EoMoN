﻿#pragma strict

enum Character {
	A,
	B,
	C,
	SENTINEL,
};

/*** キャラクタプレハブ設定 ***/
var charaPrfb : GameObject[];

/*** キャラクタ名表示用 ***/
var charaNameString : String[] = ["CharaA",
								  "CharaB",
								  "CharaC"];

/*** キャラクタセレクト用 ***/
private var selectedNum : int[] = [0, 0];
//private var selectedFlag : boolean[] = [false, false];

/*** GUI表示 ***/
var bgTexture : Texture;

/*** コンポーネント ***/
private var publicData : PublicData;
private var photonView : PhotonView;

/*****************************************************************/

function Start () {
	enabled = false;	// マッチメイクが終了するまでスクリプトを実行しない

	publicData = GameObject.Find("DataKeeper").GetComponent(PublicData);
	photonView = GetComponent(PhotonView);
	
	// 選択キャラ初期化
	publicData.playerChara[0] = null;
	publicData.playerChara[1] = null;
	
	
	// *** Debug ***
	selectedNum[0] = 0;
	publicData.playerChara[0] = charaPrfb[selectedNum[0]];
	
	selectedNum[1] = 1;
	publicData.playerChara[1] = charaPrfb[selectedNum[1]];
	// *************
}

function OnGUI () {
	if (publicData == null) return;
	
	// 1P/2P設定
	if (publicData.isOfflineMode || PhotonNetwork.isMasterClient) {
		publicData.myIndex = 0;
	} else {
		publicData.myIndex = 1;
	}
	
	GUI.DrawTexture(Rect(0,0,Screen.width,Screen.height),
	                     bgTexture, ScaleMode.StretchToFill, true);
	
	var boxW : int = 400;
	var boxH : int = 200;
	var boxX : int = (Screen.width - boxW) / 2;
	var boxY : int = (Screen.height - boxH) / 2;
	var boxMargin : int = 20;
	
	GUI.skin.box.fontStyle = FontStyle.Bold;
	GUI.Box(Rect(boxX, boxY, boxW, boxH), "Character Select");
	GUILayout.BeginArea(Rect(boxX + boxMargin, boxY + boxMargin,
							 boxW - boxMargin*2, boxH - boxMargin*2));

	GUILayout.Space(10);
	GUILayout.BeginHorizontal();

	for (var i : int = 0; i < 2; i++) {
		GUILayout.BeginVertical();
	
		if (publicData.isOfflineMode && i == 1) {
			GUILayout.Label("[ " + (i+1) + "P Character (AI) ]");
		} else {
			GUILayout.Label("[ " + (i+1) + "P Character ]");
		}
		GUILayout.Space(10);
		
		if (publicData.playerChara[i] == null) {
			if (publicData.isOfflineMode) {
				// キャラ一覧表示、キャラ名を選択した後、決定ボタンを押す
				selectedNum[i] = GUILayout.SelectionGrid(selectedNum[i], charaNameString, 1);
			
				GUILayout.Space(15);
			
				if (GUILayout.Button("決定", GUILayout.Height(25))) {
					SetplayerChara(selectedNum[i], i);
				}
			} else {
				if (i == publicData.myIndex) {
					// キャラ一覧表示、キャラ名を選択した後、決定ボタンを押す
					selectedNum[i] = GUILayout.SelectionGrid(selectedNum[i], charaNameString, 1);
				
					GUILayout.Space(15);
				
					if (GUILayout.Button("決定", GUILayout.Height(25))) {
						photonView.RPC("SendplayerChara", PhotonTargets.All, selectedNum[i], i);
					}
				} else {
					GUILayout.Label("対戦相手が選択中です");
				}
			}
			
		} else {
			// 決定された使用キャラを表示
			GUILayout.Label(charaNameString[selectedNum[i]]);
		}

		GUILayout.EndVertical();
		if (i == 0) GUILayout.Space(50);
	}
	
	GUILayout.EndHorizontal();
	GUILayout.EndArea();
	
	// ゲーム開始
	if (publicData.playerChara[0] != null &&
	    publicData.playerChara[1] != null) {
	    PhotonNetwork.isMessageQueueRunning = false;
		Application.LoadLevel(Application.loadedLevel + 1);
	}
}

/*function OnPhotonSerializeView (stream : PhotonStream, info : PhotonMessageInfo)
{
}*/


function SetplayerChara(num : int, index : int) {
	selectedNum[index] = num;
	
	publicData.playerChara[index] = charaPrfb[num];
}

@RPC

function SendplayerChara(num : int, index : int) {
	SetplayerChara(num, index);
}
