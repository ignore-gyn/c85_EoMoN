#pragma strict

private var photonView : PhotonView;


var chatMaxLine : int = 10;
var messages = new String[chatMaxLine+1];
var messagesNum : int = 10;

private var sw = Screen.width;
private var sh = Screen.height;

// ���b�Z�[�W�\���G���A
private var chatWidth : int;
private var chatHeight : int;
private var chatRect : Rect;
private var scrollPos : Vector2 = Vector2.zero;

// ���b�Z�[�W���̓G���A
private var chatInputWidth : int;
private var chatInputHeight : int = 20;
private var chatInputRect : Rect;
private var chatInput : String = "";

// ���b�Z�[�W���M�{�^��
private var chatBtnWidth : int = 40;
private var chatBtnHeight : int = chatInputHeight;
private var chatBtnRect : Rect;

private var infobarWidth : int = sw / 8;

/*****************************************************************/

function Awake()
{
	photonView = GetComponent(PhotonView);
	
    chatWidth = sw - infobarWidth*2;
    chatHeight = sh / 5;
    chatRect = Rect(infobarWidth, sh-chatHeight-chatInputHeight,
                    chatWidth, chatHeight);
    
    chatInputWidth = chatWidth - chatBtnWidth;
    chatInputRect = Rect(infobarWidth, sh-chatInputHeight,
                         chatInputWidth, chatInputHeight);
    
    chatBtnRect = Rect(sw-infobarWidth-chatBtnWidth, sh-chatInputHeight,
    	               chatBtnWidth, chatBtnHeight);
}

function OnGUI()
{
    // ���b�Z�[�W�\���G���A(�X�N���[�����X�g)
    GUILayout.BeginArea(chatRect);
    
    scrollPos = GUILayout.BeginScrollView(scrollPos);
    GUI.color = Color.black;
    
    for (var i : int = chatMaxLine; i >= 0; i--)
    	GUILayout.Label(messages[i], GUILayout.Height(chatInputHeight));
    
    GUI.color = Color.white;
    GUILayout.EndScrollView();

    GUILayout.EndArea();
    
    // ���b�Z�[�W���̓G���A
    /*GUI.SetNextControlName("chat");*/
    chatInput = GUI.TextField(chatInputRect, chatInput);
    if (GUI.Button(chatBtnRect, "Send"))
        SendChat(PhotonTargets.All);
	/*
	if (Event.current.Equals (Event.KeyboardEvent ("return")) &&
    	GUI.GetNameOfFocusedControl() == "chat") {
    	SendChat(PhotonTargets.All);
	}*/
}

function AddMessage(text : String)
{
    if (messagesNum <= chatMaxLine) {
    	messages[messagesNum++] = text;
    	return;
    }
    
    for (var i : int = 0; i < chatMaxLine; i++) messages[i] =  messages[i+1];
    messages[chatMaxLine] = text;
}


@RPC
function SendChatMessage(text : String, info : PhotonMessageInfo)
{
    AddMessage("[" + info.sender + "] " + text);
}

function SendChat(target : PhotonTargets)
{
    photonView.RPC("SendChatMessage", target, chatInput);
    chatInput = "";
}

function SendChat(target : PhotonPlayer)
{
    chatInput = "[PM] " + chatInput;
    photonView.RPC("SendChatMessage", target, chatInput);
    chatInput = "";
}
