#pragma strict

import System;
import System.IO;
import System.Text;

function Start () {
	
	// write
	var sw : StreamWriter;
	sw = new StreamWriter("c:\\utttest,txt", true);
	
	sw.WriteLine("test");
	// sw.Write("");
	sw.Flush();
	sw.Close();
	
	// read
	var sr : StreamReader;
	sr = new StreamReader("c:\\utttest,txt");
	var txt = sr.ReadToEnd();
	sr.Close();
	print(txt);
}

function Update () {

}

/*

public class Textreader : MonoBehaviour {
 
   void Start () {
    write("Hello, world!");
    read();
    }
 
    // ��������
    public void write(string text){
 
    FileInfo fi = new FileInfo(Application.dataPath+"/test.txt");
     //write
     StreamWriter sw = fi.AppendText();
     //sw.Write(text);      // �����s
     sw.WriteLine(text);        // ���s
     sw.Flush();
     sw.Close(); 
    }
    
    // �ǂݍ���
    public void read () {
        FileInfo fi = new FileInfo(Application.dataPath+"/test.txt");
        StreamReader sr = new StreamReader(fi.OpenRead());
        while( sr.Peek() != -1 ){
            print( sr.ReadLine() );
            }
       sr.Close();
    }
*/