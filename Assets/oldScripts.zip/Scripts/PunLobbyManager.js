#pragma strict

/*** コンポーネント ***/
private var publicData : PublicData;

/*** GUI表示 ***/
var bgTexture : Texture;
private var scrollPos : Vector2 = Vector2.zero;	// ルームリストスクロールバーの現在位置

/*** Photon ***/
var roomName : String = "GYN_Room";
var connectFailed : boolean = false;

private var isExistedRoom : boolean = false;
private var isMatched : boolean = false;

/*****************************************************************/

function Awake()
{
	publicData = GameObject.Find("DataKeeper").GetComponent(PublicData);
	
	// Connect to the main photon server. This is the only IP and port we ever need to set(!)
	if (!PhotonNetwork.connected) {
		PhotonNetwork.ConnectUsingSettings("1.0");
	}

	// PhotonNetwork.logLevel = NetworkLogLevel.Full; // turn on if needed

	// プレイヤー名を生成(Guest1～9999)
	if (PhotonNetwork.playerName == null || PhotonNetwork.playerName == "") {
		PhotonNetwork.playerName = "Guest" + Random.Range(1, 9999);
	}
}

function OnGUI()
{
	if (publicData == null) return;
	
	/****************************************************************
	[UI表示パターン]
	1.OfflineMode選択 + OnlineMode@ロビー
		PhotonNetwork.connected && PhotonNetwork.room == null
	2.OfflineMode選択 + Photonに接続できない(再接続要求ボタン)
		!PhotonNetwork.connected
	3.OnlineMode@ルーム(対戦相手入室待ち)
		PhotonNetwork.room != null &&
		PhotonNetwork.room.playerCount != PhotonNetwork.room.maxPlayers
	****************************************************************/
	
	// *** Debug ***
	publicData.isOfflineMode = true;
	isMatched = true;
	// *************
	
	if (!isMatched) {
		GUI.DrawTexture(Rect(0,0,Screen.width,Screen.height),
	                     bgTexture, ScaleMode.StretchToFill, true);
	    
		// GUI表示ボックスの作成
		var boxW : int = 400;
		var boxH : int = 400;
		var boxX : int = (Screen.width - boxW) / 2;
		var boxY : int = (Screen.height - boxH) / 2;
		var boxMargin : int = 20;
		
		GUI.skin.box.fontStyle = FontStyle.Bold;
		GUI.Box(Rect(boxX, boxY, boxW, boxH), "Match Making");
		GUILayout.BeginArea(Rect(boxX + boxMargin, boxY + boxMargin,
		                         boxW - boxMargin*2, boxH - boxMargin*2));
		
		GUILayout.Space(15);
		
		// @ルーム
		if (PhotonNetwork.room != null) {
			if (PhotonNetwork.room.playerCount == PhotonNetwork.room.maxPlayers) {
				isMatched = true;			// 対戦相手入室
			} else {
				guiWaitingOtherPlayer();	// 対戦相手入室待ち
			}
			
		// @ロビー
		} else {
			guiOfflineMode();				// Offlineモード選択ボタン
			
			if (PhotonNetwork.connected) {
				guiPlayerAndRoomName();		// プレイヤー名、ルーム名(作成)
				GUILayout.Space(10);
				guiRoomList();				// ルームリスト
			} else {
				guiNotConnected();			// 未接続
			}
		}
		
		GUILayout.EndArea();
	}
	
	// キャラクタセレクトへ
	if (isMatched) {
		GetComponent(CharaSelect).enabled = true;
		return;
	}
}

// *** Offlineモードのボタン ***
function guiOfflineMode () {
	if (GUILayout.Button("Offline Mode", GUILayout.Width(100))) {
		publicData.isOfflineMode = true;
		isMatched = true;
	}
	GUILayout.Label("----------------------------------------------------------");
}

// *** Photon Cloudへ接続中、接続不可時の表示 ***
function guiNotConnected () {
	if (PhotonNetwork.connectionState == ConnectionState.Connecting) {
		GUILayout.Label("Connecting " + PhotonNetwork.PhotonServerSettings.ServerAddress);
		//GUILayout.Label(Time.time.ToString());
	} else {
		GUILayout.Label("Not connected. Check console output.");
	}

	// 接続に失敗した場合、サーバアドレス、ポート番号、AppIDを設定を表示
	if (connectFailed) {
		GUILayout.Label("Connection failed. Check setup and use Setup Wizard to fix configuration.");
		GUILayout.Label("Server: " + PhotonNetwork.PhotonServerSettings.ServerAddress + 
						":" + PhotonNetwork.PhotonServerSettings.ServerPort);
		GUILayout.Label("AppId: " + PhotonNetwork.PhotonServerSettings.AppID);
		
		// 再接続要求ボタン
		GUILayout.Space(10);
		if (GUILayout.Button("Try Again", GUILayout.Width(100))) {
			connectFailed = false;
			PhotonNetwork.ConnectUsingSettings("1.0");
		}
	}
}

// *** プレイヤー名・ルーム名の表示と作成ボタン@ロビー ***
function guiPlayerAndRoomName () {
	GUILayout.Label("[ Online Mode ]");
	
	// プレイヤー名
	GUILayout.BeginHorizontal();
	
	GUILayout.Label("Player Name:", GUILayout.Width(80));
	PhotonNetwork.playerName = GUILayout.TextField(PhotonNetwork.playerName);
	if (GUI.changed) {
		// プレイヤー名を保存
		PlayerPrefs.SetString("playerName", PhotonNetwork.playerName);
	}
	GUILayout.EndHorizontal();
	
	// ルーム名
	GUILayout.BeginHorizontal();
	
	GUILayout.Label("Room Name:", GUILayout.Width(80));
	roomName = GUILayout.TextField(roomName);
	
	// ルーム作成(Create)ボタン
	if (PhotonNetwork.room == null) {
		if (GUILayout.Button("作成", GUILayout.MaxWidth(40))) {
			// ルーム最大人数：2
			if (roomName != "")
				PhotonNetwork.CreateRoom(this.roomName, true, true, 2);
		}
	}
	GUILayout.EndHorizontal();
	
	if (isExistedRoom) {
		GUILayout.Label("                      既に存在するルーム名です");
		if (roomName != "") isExistedRoom = false;
	}
}


// *** ルームリストの表示と入室ボタン@ロビー ***
function guiRoomList () {
	var isRoomOpen : boolean = false;	// 入室可能ルームの存在フラグ
	
	// オンラインプレイヤー数、ルーム数
	GUILayout.Label(PhotonNetwork.countOfPlayers + " users are online in "+
	                PhotonNetwork.countOfRooms + " rooms.");
	
	GUILayout.Space(10);
	
	// ルームリスト(入室可能なルームのみ表示)
	GUILayout.Label("Room List:");
	if (PhotonNetwork.GetRoomList().Length == 0) {
		GUILayout.Label("Roomを作成してください");
		
	} else {
		scrollPos = GUILayout.BeginScrollView(scrollPos);
		for (roomInfo in PhotonNetwork.GetRoomList()) {
			GUILayout.BeginHorizontal();
			if (roomInfo.playerCount < roomInfo.maxPlayers) {
				GUILayout.Label(roomInfo.name + " " +
			                roomInfo.playerCount + "/" + roomInfo.maxPlayers);
			    
			    // ルーム入室(Join)ボタン
				if (GUILayout.Button("入室", GUILayout.Width(40))) {
					PhotonNetwork.JoinRoom(roomInfo.name);
				}
				
				isRoomOpen = true;
			}
			GUILayout.EndHorizontal();
		}
		
		if (!isRoomOpen) GUILayout.Label("Roomを作成してください");
		GUILayout.EndScrollView();
	}
}

// *** 対戦相手待ち表示と退室ボタン@ルーム ***
function guiWaitingOtherPlayer () {
	GUILayout.Label("対戦相手を待っています");
	GUILayout.Label("Please Wait...");
	
	// 退室ボタン
	GUILayout.Space(10);
	if (GUILayout.Button("退室", GUILayout.Width(40))) {
		PhotonNetwork.LeaveRoom();
	}
}


/****************************************************************
	PhotonNetworkingMessage
****************************************************************/
// 入室
function OnJoinedRoom()
{
}

// 部屋作成
function OnCreatedRoom()
{
	Debug.Log("OnCreatedRoom");
}

// 部屋作成失敗
function OnPhotonCreateRoomFailed()
{
	Debug.Log("CreateRoom is failed");
	isExistedRoom = true;
	roomName = "";
}

// 退室
function OnLeftRoom()
{
    Debug.Log("OnLeftRoom (local)");
}

// 切断
function OnDisconnectedFromPhoton()
{
	Debug.Log("Disconnected from Photon.");
}

// 接続失敗時のステータス取得
function OnFailedToConnectToPhoton(parameters)
{
	connectFailed = true;
	Debug.Log("OnFailedToConnectToPhoton. StatusCode: " + parameters);
}

// 対戦プレイヤー入室
function OnPhotonPlayerConnected(player : PhotonPlayer)
{
    Debug.Log("OnPhotonPlayerDisconnected: " + player);
}

// 対戦プレイヤー退室
function OnPhotonPlayerDisconnected(player : PhotonPlayer)
{
    Debug.Log("OnPhotonPlayerConnected: " + player);
}
