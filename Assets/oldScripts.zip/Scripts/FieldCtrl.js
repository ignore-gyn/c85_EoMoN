﻿#pragma strict

// フィールド外に出る弾を消す
function OnTriggerExit (other : Collider) {
	if (other.gameObject.tag == "Bullet") {
		Destroy(other.gameObject);
	}
}